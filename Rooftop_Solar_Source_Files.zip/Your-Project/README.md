# Rooftop Solar Energy Monitoring System

A small Java console project that demonstrates how rooftop solar readings can be monitored.

> **Important:** This is an educational simulation. Voltage and current values are hard-coded demo data; the project does not connect to a real solar panel, sensor, inverter, or cloud service.

## Project structure

```text
Your-Project/
├── src/
│   ├── Main.java
│   ├── SolarPanel.java
│   └── EnergyMonitor.java
├── bin/
│   ├── Main.class
│   ├── SolarPanel.class
│   ├── SolarPanel$Reading.class
│   └── EnergyMonitor.class
└── README.md
```

## Features

- Displays sample voltage (V) and current (A) readings.
- Calculates power using `Power (W) = Voltage (V) × Current (A)`.
- Estimates cumulative energy in kWh using a five-minute sample interval.
- Shows a simple generation status for each reading.
- Uses separate classes for the panel model and monitoring logic.

## Requirements

- Java Development Kit (JDK) 8 or later.
- A terminal / command prompt.

## Compile and run

From the `Your-Project` folder:

### Windows

```bat
javac -d bin src\SolarPanel.java src\EnergyMonitor.java src\Main.java
java -cp bin Main
```

### macOS / Linux

```bash
javac -d bin src/SolarPanel.java src/EnergyMonitor.java src/Main.java
java -cp bin Main
```

## How the calculation works

For each sample:

- `Power (W) = Voltage (V) × Current (A)`
- `Energy (kWh) += Power (W) × sample interval (hours) ÷ 1000`

The example uses a five-minute interval. Since the values are simulated, the output is only a demonstration and must not be treated as measured solar production.

## Files

- `src/Main.java` — starts the program and prints each reading.
- `src/SolarPanel.java` — represents the panel and generates sample readings.
- `src/EnergyMonitor.java` — calculates estimated energy and classifies status.
- `bin/` — compiled Java class files (rebuild them with the commands above if needed).

## Safety and future improvements

Do not connect this demo directly to PV wiring. Real hardware needs correctly rated, calibrated sensors, suitable isolation, protected enclosures, and qualified supervision. Possible extensions include sensor integration, data logging, charts, a web dashboard, alerts, and inverter integration.

## Upload to GitHub

1. Sign in to GitHub and create a new repository named `rooftop-solar-energy-monitor`.
2. Extract this ZIP file.
3. Open a terminal inside `Your-Project`.
4. Run:

```bash
git init
git add .
git commit -m "Initial rooftop solar monitoring project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/rooftop-solar-energy-monitor.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. The URL above is a template, not an existing repository.
