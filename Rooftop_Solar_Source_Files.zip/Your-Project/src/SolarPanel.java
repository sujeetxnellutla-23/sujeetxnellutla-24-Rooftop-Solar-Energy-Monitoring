import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a rooftop solar panel and provides demo readings.
 * Replace the demo data source with properly isolated, calibrated sensors
 * before using this project with real hardware.
 */
public class SolarPanel {
    private final String panelName;
    private final double ratedVoltage;
    private final double ratedCurrent;

    public SolarPanel(String panelName, double ratedVoltage, double ratedCurrent) {
        if (panelName == null || panelName.trim().isEmpty()) {
            throw new IllegalArgumentException("Panel name cannot be empty.");
        }
        if (ratedVoltage <= 0 || ratedCurrent <= 0) {
            throw new IllegalArgumentException("Rated voltage and current must be positive.");
        }
        this.panelName = panelName;
        this.ratedVoltage = ratedVoltage;
        this.ratedCurrent = ratedCurrent;
    }

    public String getPanelName() {
        return panelName;
    }

    public double getRatedVoltage() {
        return ratedVoltage;
    }

    public double getRatedCurrent() {
        return ratedCurrent;
    }

    /** Returns illustrative sample readings for a console demonstration. */
    public List<Reading> getDemoReadings() {
        double[][] samples = {
            {22.8, 2.4},
            {23.5, 3.0},
            {24.1, 3.2},
            {20.2, 1.1},
            {0.0, 0.0}
        };

        List<Reading> readings = new ArrayList<>();
        LocalDateTime time = LocalDateTime.now();
        for (int i = 0; i < samples.length; i++) {
            readings.add(new Reading(
                panelName,
                time.plusMinutes(i * 5),
                samples[i][0],
                samples[i][1]
            ));
        }
        return readings;
    }

    public static class Reading {
        private final String panelName;
        private final LocalDateTime timestamp;
        private final double voltage;
        private final double current;

        public Reading(String panelName, LocalDateTime timestamp,
                       double voltage, double current) {
            if (voltage < 0 || current < 0) {
                throw new IllegalArgumentException("Voltage and current cannot be negative.");
            }
            this.panelName = panelName;
            this.timestamp = timestamp;
            this.voltage = voltage;
            this.current = current;
        }

        public String getPanelName() { return panelName; }
        public LocalDateTime getTimestamp() { return timestamp; }
        public double getVoltage() { return voltage; }
        public double getCurrent() { return current; }
        public double getPowerWatts() { return voltage * current; }

        @Override
        public String toString() {
            return String.format(
                "%s | %s | Voltage: %.2f V | Current: %.2f A",
                panelName,
                timestamp.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                voltage,
                current
            );
        }
    }
}
