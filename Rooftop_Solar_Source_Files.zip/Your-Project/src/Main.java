import java.util.List;

/**
 * Entry point for the Rooftop Solar Energy Monitoring System.
 * This educational version uses simulated readings, not real solar sensors.
 */
public class Main {
    public static void main(String[] args) {
        SolarPanel panel = new SolarPanel("Rooftop Panel 1", 24.0, 3.2);
        EnergyMonitor monitor = new EnergyMonitor();

        System.out.println("==============================================");
        System.out.println("   ROOFTOP SOLAR ENERGY MONITORING SYSTEM");
        System.out.println("==============================================");
        System.out.println("Mode: DEMO (simulated readings; no real sensors)");
        System.out.println();

        List<SolarPanel.Reading> readings = panel.getDemoReadings();
        for (SolarPanel.Reading reading : readings) {
            monitor.recordReading(reading);
            System.out.println(reading);
            System.out.printf("Calculated power : %.2f W%n", reading.getPowerWatts());
            System.out.printf("Estimated energy : %.4f kWh (cumulative)%n",
                    monitor.getEnergyKWh());
            System.out.println("System status    : " + monitor.getStatus(reading));
            System.out.println("----------------------------------------------");
        }

        System.out.printf("Total estimated energy: %.4f kWh%n", monitor.getEnergyKWh());
        System.out.println("Demo complete.");
    }
}
