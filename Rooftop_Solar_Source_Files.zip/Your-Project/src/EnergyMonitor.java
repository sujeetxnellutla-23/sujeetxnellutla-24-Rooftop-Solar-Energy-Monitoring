/**
 * Processes solar readings, estimates cumulative energy and reports status.
 * Energy is approximated from each sample interval using the current sample's
 * power and a fixed five-minute interval.
 */
public class EnergyMonitor {
    private static final double SAMPLE_INTERVAL_HOURS = 5.0 / 60.0;
    private double energyKWh = 0.0;

    public void recordReading(SolarPanel.Reading reading) {
        if (reading == null) {
            throw new IllegalArgumentException("Reading cannot be null.");
        }
        // Convert watt-hours to kilowatt-hours.
        energyKWh += (reading.getPowerWatts() * SAMPLE_INTERVAL_HOURS) / 1000.0;
    }

    public double getEnergyKWh() {
        return energyKWh;
    }

    public String getStatus(SolarPanel.Reading reading) {
        double power = reading.getPowerWatts();
        if (power <= 1.0) {
            return "NO / VERY LOW GENERATION";
        } else if (power < 50.0) {
            return "LOW GENERATION (demo threshold)";
        }
        return "GENERATING";
    }
}
